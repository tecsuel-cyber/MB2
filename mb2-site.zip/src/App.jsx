export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 text-gray-800 flex flex-col">
      {/* Header */}
      <header className="p-6 bg-white shadow-md flex justify-center">
        <h1 className="text-3xl font-bold text-blue-600">MB2 Comunicação</h1>
      </header>

      {/* Hero */}
      <section className="flex-1 flex flex-col items-center justify-center text-center px-6">
        <h2 className="text-2xl md:text-4xl font-semibold mb-4">
          Transformando ideias em comunicação eficaz
        </h2>
        <p className="max-w-2xl text-gray-600 mb-8">
          A MB2 Comunicação ajuda sua marca a se destacar, conectando pessoas e criando experiências únicas.
        </p>
        <a
          href="https://wa.me/5599999999999"
          target="_blank"
          rel="noopener noreferrer"
          className="bg-blue-600 text-white px-6 py-3 rounded-full shadow hover:bg-blue-700 transition"
        >
          Fale Conosco
        </a>
      </section>

      {/* Serviços */}
      <section className="bg-white py-12 px-6">
        <h3 className="text-2xl font-bold text-center mb-8">Nossos Serviços</h3>
        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          <div className="p-6 bg-blue-50 rounded-xl shadow">
            <h4 className="font-semibold mb-2">Marketing Digital</h4>
            <p className="text-gray-600">Gestão de redes sociais, campanhas online e presença digital estratégica.</p>
          </div>
          <div className="p-6 bg-blue-50 rounded-xl shadow">
            <h4 className="font-semibold mb-2">Design e Branding</h4>
            <p className="text-gray-600">Criação de identidade visual, logotipos e materiais gráficos impactantes.</p>
          </div>
          <div className="p-6 bg-blue-50 rounded-xl shadow">
            <h4 className="font-semibold mb-2">Comunicação Corporativa</h4>
            <p className="text-gray-600">Estratégias de comunicação interna e externa para fortalecer sua marca.</p>
          </div>
        </div>
      </section>

      {/* Contato */}
      <footer className="bg-blue-600 text-white text-center p-6">
        <p className="mb-2">Entre em contato:</p>
        <div className="flex justify-center gap-4">
          <a href="mailto:contato@mb2comunicacao.com" className="hover:underline">
            Email
          </a>
          <a href="https://instagram.com/mb2comunicacao" target="_blank" rel="noopener noreferrer" className="hover:underline">
            Instagram
          </a>
          <a href="https://wa.me/5599999999999" target="_blank" rel="noopener noreferrer" className="hover:underline">
            WhatsApp
          </a>
        </div>
        <p className="mt-4 text-sm">© {new Date().getFullYear()} MB2 Comunicação. Todos os direitos reservados.</p>
      </footer>
    </div>
  )
}
